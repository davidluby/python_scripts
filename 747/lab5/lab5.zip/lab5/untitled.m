clear all
close all
dta = xlsread("Instrument Capture 2022-11-01 14-38-10 Oscilloscope - Waveform Data.csv");

t = dta(:,1);
y = dta(:,2);

plot(t)